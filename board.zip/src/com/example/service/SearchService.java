package com.example.service;

import com.common.AppService;
import com.common.ServiceForward;
import com.example.ds.ExampleDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.regex.Pattern;

import static com.common.Constants.BASIC_VIEW_PATH;

public class SearchService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // String형 input을 선언하고 입력한 id를 로드하여 저장한다.
        String input = request.getParameter("myNameId");

        // input 변수의 데이터가 숫자인 확인한다.
        if (input == null || input.equals("") || !Pattern.matches("^[0-9]{1,9}$", input)) {
            // 오류 메시지
            return null;
        }

        // 정수형 id를 선언하고 input 변수를 숫자로 변환한다.
        int id = Integer.parseInt(input);

        // String형 name을 선언하고 데이터베이스에서 id로 이름을 검색하여 저장한다.
        ExampleDs ds = new ExampleDs();
        String name = ds.selectNameById(id);
        if (name == null) {
            name = "검색 결과가 존재하지 않습니다.";
        }

        // request 객체의 attribute에 검색한 이름을 저장한다.
        request.setAttribute("result", name);

        // view를 위한 forward 객체 리턴
        return ServiceForward.builder()
                .path(BASIC_VIEW_PATH + "search.jsp")
                .build();
    }
}














