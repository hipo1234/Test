package com.board.service;

import com.board.ds.BoardDs;
import com.common.*;
import com.dto.BoardDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AjaxBoardUpdateService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 로그인 여부 확인
        if (!LoginUtil.isLogin(request)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // 데이터 검사
        String title = request.getParameter("title");
        String contents = request.getParameter("contents");
        String id = request.getParameter("aid");
        if (title == null || title.equals("") || title.length() > 50
                || contents == null || contents.equals("")
                || !Validator.isValidated(id, "^[0-9]*$", true)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // 특수기호 문자열로 변환

        // 저장
        BoardDTO dto = BoardDTO.builder()
                .title(title)
                .contents(contents)
                .registerId(LoginUtil.getMemberId(request))
                .id(Integer.parseInt(id))
                .build();
        BoardDs ds = new BoardDs();
        boolean isSuccess = ds.updateBoard(dto);
        if (!isSuccess) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "글 수정에 실패하였습니다.");
        }

        return AjaxUtil.buildAjaxResult
                (request, true, "글을 수정하였습니다.");
    }
}














