package com.board.service;

import com.board.ds.BoardDs;
import com.common.AjaxUtil;
import com.common.AppService;
import com.common.LoginUtil;
import com.common.ServiceForward;
import com.dto.BoardDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.common.Constants.BASIC_VIEW_PATH;
import static com.common.Validator.isValidated;

public class BoardUpdateService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 로그인 여부 확인
        if (!LoginUtil.isLogin(request)) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('잘못된 접근입니다.');history.back();")
                    .build();
        }

        // id 데이터 로드
        String id = request.getParameter("aid");
        // 데이터 확인
        if (!isValidated(id, "^[0-9]*$", true)) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('잘못된 접근입니다.');history.back();")
                    .build();
        }

        // 데이터베이스에서 아이디로 글 검색
        BoardDs ds = new BoardDs();
        BoardDTO dto = ds.selectBoardDetailById(Integer.parseInt(id));
        if (dto == null) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('존재하지 않는 글입니다.');history.back();")
                    .build();
        }

        if (LoginUtil.getMemberId(request) != dto.getRegisterId()) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('잘못된 접근입니다.');history.back();")
                    .build();
        }

        // 뷰 이동 데이터 세팅 및 리턴
        request.setAttribute("dto", dto);
        return ServiceForward.builder()
                .path(BASIC_VIEW_PATH + "board/updateform.jsp")
                .build();
    }
}














