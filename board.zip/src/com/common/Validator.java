package com.common;

import java.util.regex.Pattern;

public class Validator {
    public static boolean isValidated(String data, String regexp, boolean isEssential) {
        boolean isValidated = true;

        if (isEssential) {  // 필수값일 경우
            if (data == null || data.equals("") || !Pattern.matches(regexp, data)) {
                isValidated = false;
            }
        } else {    // 선택값일 경우
            if (data != null && !data.equals("") && !Pattern.matches(regexp, data)) { // 데이터 입력 시
                isValidated = false;
            }
        }
        return isValidated;
    }

    public static boolean isStringEmpty(String str) {
        return str == null || str.isEmpty();
    }

    public static String changeToString(String str) {
        if (str != null) {
            str = str.replaceAll("&", "&amp;");
            str = str.replaceAll("<", "&lt;");
            str = str.replaceAll(">", "&gt;");
            str = str.replaceAll("'", "&#039;");
            str = str.replaceAll("\"", "&quot;");
            str = str.replaceAll("<br>", "\r\n;");
        }
        return str;
    }

    public static String changeToHtml(String str) {
        if (str != null) {
            str = str.replaceAll("&amp;", "&");
            str = str.replaceAll("&lt;", "<");
            str = str.replaceAll("&gt;", ">");
            str = str.replaceAll("&#039;", "'");
            str = str.replaceAll("&quot;", "\"");
            str = str.replaceAll("\r\n;", "<br>");
        }

        return str;
    }
}









