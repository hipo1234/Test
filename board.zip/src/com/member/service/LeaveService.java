package com.member.service;

import com.common.*;
import com.dto.MemberDTO;
import com.member.ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LeaveService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (!LoginUtil.isLogin(request)) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('잘못된 접근입니다.');history.back();")
                    .build();
        }

        int id = LoginUtil.getMemberId(request);

        // id를 이용하여 탈퇴 처리
        MemberDs ds = new MemberDs();
        boolean isSuccess = ds.updateLeave(id);
        if (!isSuccess) {
            return ServiceForward.builder()
                    .fail(true)
                    .message("alert('회원 탈퇴에 실패하였습니다.');history.back();")
                    .build();
        }

        // 로그아웃
        HttpSession session = request.getSession();
        session.removeAttribute("mi");
        session.invalidate();

        return ServiceForward.builder()
                .path("/")
                .redirect(true)
                .build();
    }
}














