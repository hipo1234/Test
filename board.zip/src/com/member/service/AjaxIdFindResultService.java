package com.member.service;

import com.common.AjaxUtil;
import com.common.AppService;
import com.common.LoginUtil;
import com.common.ServiceForward;
import com.dto.MemberDTO;
import com.member.ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;

import static com.common.Validator.isValidated;

public class AjaxIdFindResultService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (LoginUtil.isLogin(request)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // 폼 데이터 로드
        // 이름, 휴대전화번호, 생년월일, 이메일, 주소3
        String name = request.getParameter("name");
        String mobileNo = request.getParameter("mobileNo");
        String email = request.getParameter("email");

        // 데이터 확인
        if (!isValidated(name, "^[가-힣]{2,10}$", true)
                || !isValidated(mobileNo, "^[0-9]{10,12}$", true)
                || !isValidated(email, "^.{1,50}$", true)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // DTO 데이터 세팅
        MemberDTO memberDTO = MemberDTO.builder()
                .name(name)
                .mobileNo(mobileNo)
                .email(email)
                .build();

        // 데이터베이스에서 회원 정보 검색
        MemberDs ds = new MemberDs();
        String loginId = ds.selectLoginIdForFindId(memberDTO);
        if (loginId == null) {
            return AjaxUtil.buildAjaxResult
                    (request, true, "회원 정보를 찾을 수 없습니다.");
        } else {
            return AjaxUtil.buildAjaxResult
                    (request, true, "검색 결과 : " + loginId);
        }
    }
}














