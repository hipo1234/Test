package com.member.service;

import com.common.*;
import com.dto.MemberDTO;
import com.member.ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;

import static com.common.Constants.BASIC_VIEW_PATH;
import static com.common.Validator.isValidated;

public class AjaxPasswordUpdateService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 로그인 여부 확인
        if (LoginUtil.isLogin(request)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        HttpSession session = request.getSession();
        Integer id = (Integer) session.getAttribute("memberId");
        if (id == null) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // 폼 데이터 로드
        // 아이디, 비밀번호, 비밀번호확인, 이름, 휴대전화번호, 생년월일, 이메일, 주소3
        String password = request.getParameter("password");
        String passwordCheck = request.getParameter("passwordCheck");

        // 데이터 확인
        if (!isValidated(password, "^[a-zA-Z0-9!@#$]{4,15}$", true)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        if (!password.equals(passwordCheck)) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "잘못된 접근입니다.");
        }

        // 비밀번호 암호화(복호화가 불가능)
        password = BCrypt.hashpw(password, BCrypt.gensalt(12));

        // DTO 데이터 세팅
        MemberDTO memberDTO = MemberDTO.builder()
                .id(id)
                .password(password)
                .build();

        // 데이터베이스에 저장
        MemberDs ds = new MemberDs();
        boolean isSuccess = ds.updateMemberPassword(memberDTO);
        if (!isSuccess) {
            return AjaxUtil.buildAjaxResult
                    (request, false, "비밀번호 변경에 실패하였습니다.");
        }

        session.removeAttribute("memberId");

        // 뷰 이동 데이터 세팅 및 리턴
        return AjaxUtil.buildAjaxResult
                (request, true
                        , "비밀번호를 변경하였습니다.\\n변경된 비밀번호로 로그인해 주세요.");

    }
}














