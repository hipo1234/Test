package com.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class BoardDTO {
    private int id;
    private String title;
    private String contents;
    private int hits;
    private int registerId;
    private String registerDatetime;
    private String registerLoginId;
}
