function getValueOfParameter(key) {
    var urlParams = new URLSearchParams(location.search);
    var value = urlParams.get(key);
    if (value == null || value == undefined) {
        value = "";
    }
    return value;
}